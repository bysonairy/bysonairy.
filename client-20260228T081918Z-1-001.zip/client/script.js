/* =========================================
   BYSONAIRY - MASTER SCRIPT (V5 - NOTIFICATIONS)
   ========================================= */

const API_URL = "http://localhost:5000/api/products"; 
const API_BASE = "http://localhost:5000/api";

// 1. SYSTEM STARTUP
window.onload = function() {
    updateCartCount();
    activateMenu();
    checkLoginStatus();

    // Determine which page logic to run
    if (document.getElementById('product-container')) {
        loadHomeProducts(); 
    } 
    else if (document.getElementById('cart-items-container')) {
        loadCartPage(); 
    }
};

/* ================= AUTHENTICATION ================= */
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('bysoniryUser'));
}

function checkLoginStatus() {
    const user = getCurrentUser();
    const userBtn = document.querySelector('a[href="login.html"]');

    if (user && userBtn) {
        // Initials Logic
        const initials = user.name.substring(0, 2).toUpperCase();
        userBtn.innerHTML = `<span style="font-weight:800; font-family:'Barlow Condensed'; font-size:1.1rem;">${initials}</span>`;
        
        // Profile Circle Style
        userBtn.style.border = "1px solid #2997FF"; 
        userBtn.style.color = "#2997FF";
        userBtn.style.borderRadius = "50%";
        userBtn.style.width = "40px";
        userBtn.style.height = "40px";
        userBtn.style.display = "flex";
        userBtn.style.alignItems = "center";
        userBtn.style.justifyContent = "center";
        
        // Redirect to Profile Page
        userBtn.href = "profile.html"; 
        userBtn.onclick = null;
    }
}

/* ================= HOME RENDERER ================= */
async function loadHomeProducts() {
    const container = document.getElementById('product-container');
    if (!container) return;

    try {
        const response = await fetch(API_URL);
        const products = await response.json();
        
        container.innerHTML = ''; 
        container.className = 'portfolio-column';

        if(products.length === 0) {
             container.innerHTML = "<p style='color:#666; text-align:center;'>No operational units detected.</p>";
             return;
        }

        products.forEach((product) => {
            let displayImage = 'download.jpeg'; 
            if (product.images && product.images.length > 0) displayImage = product.images[0]; 
            else if (product.image) displayImage = product.image; 

            // Only show partial details here (Showcase Mode)
            let specRows = `<tr><th>Unit Estimation</th><td style="color:#2997FF; font-weight:700;">₹${product.price}</td></tr>`;

            container.innerHTML += `
                <div class="b2b-card reveal-on-scroll" style="flex-direction: row;">
                    <div class="b2b-image-box">
                        <img src="${displayImage}" alt="${product.name}" onerror="this.src='download.jpeg'">
                    </div>
                    
                    <div class="b2b-info-box">
                        <h3 class="b2b-title">${product.name}</h3>
                        <p style="color:#888; margin-bottom:15px; font-size:0.9rem;">${product.description.substring(0, 100)}...</p>
                        
                        <table class="spec-table">${specRows}</table>
                        
                        <div class="b2b-actions">
                            <button class="btn-specs" onclick="window.location.href='product.html?id=${product._id}'">
                                VIEW FULL INTEL <i class="fa-solid fa-arrow-right" style="margin-left:10px;"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        if(typeof setupScrollObserver === 'function') setupScrollObserver();
    } catch (e) { console.error(e); }
}

/* ================= ANIMATION ================= */
function setupScrollObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) entry.target.classList.add('revealed'); 
        });
    }, { threshold: 0.1 }); 
    document.querySelectorAll('.reveal-on-scroll').forEach((el) => observer.observe(el));
}

/* ================= CART LOGIC ================= */
function getCartKey() {
    const user = getCurrentUser();
    return user ? `bysoniryCart_${user.email}` : 'bysoniryCart_guest';
}
function updateCartCount() { 
    const cart = JSON.parse(localStorage.getItem(getCartKey())) || [];
    document.querySelectorAll('.cart-count').forEach(el => el.innerText = `(${cart.length})`); 
}
function loadCartPage() {
    const container = document.getElementById('cart-items-container');
    const summaryBox = document.getElementById('cart-summary-box');
    if (!container) return;

    container.innerHTML = '';
    const cart = JSON.parse(localStorage.getItem(getCartKey())) || [];

    if (cart.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding: 100px 0; opacity: 0.5;"><h2>No Pending Inquiries</h2></div>`;
        if(summaryBox) summaryBox.style.display = "none";
        return;
    }

    if(summaryBox) summaryBox.style.display = "flex";

    cart.forEach((item, index) => {
        container.innerHTML += `
            <div class="cart-row">
                <div class="cart-thumb"><img src="${item.image}" onerror="this.src='download.jpeg'"></div>
                <div class="cart-details">
                    <h3 class="cart-item-title">${item.name}</h3>
                    <p class="cart-item-price" style="color:#2997FF">Ready for Quote</p>
                </div>
                <button class="btn-remove" onclick="removeFromCart(${index})">Remove</button>
            </div>`;
    });
}
window.removeFromCart = function(index) { 
    const cart = JSON.parse(localStorage.getItem(getCartKey())) || [];
    cart.splice(index, 1); 
    localStorage.setItem(getCartKey(), JSON.stringify(cart)); 
    loadCartPage(); 
    updateCartCount();
};

/* ================= CHECKOUT ================= */
window.handleCheckout = async function() {
    const user = getCurrentUser();
    if (!user) {
        alert("ACCESS DENIED: Please Login to submit inquiry.");
        window.location.href = "login.html";
        return;
    }

    const cart = JSON.parse(localStorage.getItem(getCartKey())) || [];
    const btn = document.querySelector('.btn-checkout');
    btn.innerText = "SENDING..."; btn.disabled = true;

    try {
        const res = await fetch(`${API_BASE}/checkout`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: user.email, cart: cart })
        });
        const data = await res.json();

        if (data.success) {
            alert("INQUIRY SENT. Check your Profile Notifications for updates.");
            localStorage.removeItem(getCartKey());
            window.location.href = "profile.html"; // Go to profile to see the notification!
        } else {
            alert("Error: " + data.message);
            btn.innerText = "TRY AGAIN"; btn.disabled = false;
        }
    } catch (e) {
        alert("Connection Failed.");
        btn.innerText = "SUBMIT"; btn.disabled = false;
    }
};

/* ================= MENU ================= */
function activateMenu() {
    const open = document.getElementById('open-menu');
    const close = document.getElementById('close-menu');
    const overlay = document.getElementById('menu-overlay');
    if(open && overlay) open.onclick = () => overlay.classList.add('active');
    if(close && overlay) close.onclick = () => overlay.classList.remove('active');
}
window.closeMenu = function() {
    const overlay = document.getElementById('menu-overlay');
    if(overlay) overlay.classList.remove('active');
}
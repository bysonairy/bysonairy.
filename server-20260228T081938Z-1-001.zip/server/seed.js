/* =========================================
   BYSONIRY DATA SEEDER (Generic Mode)
   Uploads generic placeholders to test the connection
   ========================================= */

require('dotenv').config();
const mongoose = require('mongoose');

// 1. Connect to Database
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('>> Seeder Connected to Neural Core'))
    .catch(err => console.log(err));

// 2. Define the Product Schema
const productSchema = new mongoose.Schema({
    id: Number,
    name: String,
    price: Number,
    image: String,
    description: String
});

const Product = mongoose.model('Product', productSchema);

// 3. The Generic Data
const products = [
    {
        id: 1,
        name: "Product 1",
        price: 5000,
        image: "download.jpeg",
        description: "Test description for Product 1."
    },
    {
        id: 2,
        name: "Product 2",
        price: 12000,
        image: "download.jpeg", 
        description: "Test description for Product 2."
    },
    {
        id: 3,
        name: "Product 3",
        price: 8500,
        image: "download.jpeg",
        description: "Test description for Product 3."
    },
    {
        id: 4,
        name: "Product 4",
        price: 2500,
        image: "download.jpeg",
        description: "Test description for Product 4."
    },
    {
        id: 5,
        name: "Product 5",
        price: 15000,
        image: "download.jpeg",
        description: "Test description for Product 5."
    }
];

// 4. Run the Upload
const seedDB = async () => {
    try {
        await Product.deleteMany({}); // Clear any old data first
        await Product.insertMany(products); // Insert our new list
        console.log('>> SUCCESS: 5 Generic Products Uploaded.');
    } catch (error) {
        console.log('>> Upload Failed:', error);
    } finally {
        mongoose.connection.close(); // Close connection
        console.log('>> Connection Closed.');
    }
};

seedDB();

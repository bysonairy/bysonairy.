/* =========================================
   BYSONAIRY - PRO SERVER (CONNECTION FIXED)
   ========================================= */
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

// 1. FORCE-ALLOW ALL CONNECTIONS (Manual Headers)
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*"); 
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    next();
});

app.use(cors());
app.use(bodyParser.json());

// 2. DEBUG LOGGER
app.use((req, res, next) => {
    console.log(`[INCOMING SIGNAL] ${req.method} ${req.url}`);
    next();
});

// 3. DATABASE CONNECTION
mongoose.connect("mongodb://127.0.0.1:27017/bysonairy")
  .then(() => console.log("--- NEURAL CORE ONLINE (LOCAL) ---"))
  .catch((err) => console.log("--- CORE FAILURE ---", err));

// --- SCHEMAS ---
const productSchema = new mongoose.Schema({ name: String, price: Number, description: String, images: [String], specs: [{ key: String, value: String }], details: [String] });
const Product = mongoose.model('Product', productSchema);

const orderSchema = new mongoose.Schema({ userEmail: String, date: { type: Date, default: Date.now }, status: { type: String, default: 'Pending' }, items: [{ name: String, qty: Number, price: Number }] });
const Order = mongoose.model('Order', orderSchema);

const userSchema = new mongoose.Schema({ name: String, email: { type: String, unique: true }, password: String, role: { type: String, default: 'user' } });
const User = mongoose.model('User', userSchema);

const notificationSchema = new mongoose.Schema({ email: String, message: String, date: { type: Date, default: Date.now }, read: { type: Boolean, default: false }, type: { type: String, default: 'info' } });
const Notification = mongoose.model('Notification', notificationSchema);

// --- ROUTES ---

// NOTIFICATIONS
app.get('/api/notifications', async (req, res) => {
    try {
        const { email } = req.query;
        if (!email) return res.json([]);
        const cleanEmail = email.toLowerCase().trim();
        const notes = await Notification.find({ email: cleanEmail }).sort({ date: -1 });
        res.json(notes);
    } catch (e) { res.status(500).json({ error: "Server Error" }); }
});

app.put('/api/notifications/read', async (req, res) => {
    try {
        const { email } = req.body;
        const cleanEmail = email.toLowerCase().trim();
        await Notification.updateMany({ email: cleanEmail, read: false }, { read: true });
        res.json({ success: true });
    } catch (e) { res.json({ success: false }); }
});

app.post('/api/notifications', async (req, res) => {
    try {
        const { email, message, type } = req.body;
        const cleanEmail = email.toLowerCase().trim();
        await new Notification({ email: cleanEmail, message, type }).save();
        res.json({ success: true });
    } catch (e) { res.json({ success: false }); }
});

// PRODUCTS & ORDERS
app.get('/api/products', async (req, res) => { const products = await Product.find(); res.json(products); });
app.post('/api/products', async (req, res) => { try { const newProduct = new Product(req.body); await newProduct.save(); res.json(newProduct); } catch(e) { res.status(500).json({}); } });
app.put('/api/products/:id', async (req, res) => { await Product.findByIdAndUpdate(req.params.id, req.body); res.json({ success: true }); });
app.delete('/api/products/:id', async (req, res) => { await Product.findByIdAndDelete(req.params.id); res.json({ success: true }); });

app.get('/api/orders', async (req, res) => { try { const { email, type } = req.query; let filter = {}; if(email) filter.userEmail = email.toLowerCase().trim(); if(type === 'past') filter.status = 'Delivered'; else if(type === 'active') filter.status = { $ne: 'Delivered' }; const orders = await Order.find(filter).sort({ date: -1 }); res.json(orders); } catch(e) { res.json([]); } });

app.post('/api/checkout', async (req, res) => {
    try {
        const { email, cart } = req.body;
        const cleanEmail = email.toLowerCase().trim();
        const items = cart.map(i => ({ name: i.name, qty: i.qty || 1, price: i.price }));
        const newOrder = new Order({ userEmail: cleanEmail, items, status: "Pending" });
        await newOrder.save();
        await new Notification({ email: cleanEmail, message: "Order Received. We are reviewing your manifest.", type: "alert" }).save();
        res.json({ success: true });
    } catch(e) { res.json({ success: false }); }
});

app.put('/api/orders/:id', async (req, res) => {
    try {
        const { status } = req.body;
        const order = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true });
        if(order) {
            let msg = `Update: Your order is now in ${status} status.`;
            if(status === 'Production') msg = "Update: Fabrication has begun.";
            if(status === 'Testing') msg = "Update: Quality assurance testing in progress.";
            if(status === 'Shipped') msg = "Update: Order dispatched.";
            if(status === 'Delivered') msg = "Success: Order Delivered.";
            await new Notification({ email: order.userEmail, message: msg, type: "info" }).save();
        }
        res.json({ success: true });
    } catch(e) { res.json({ success: false }); }
});

app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const cleanEmail = email.toLowerCase().trim();
        let role = cleanEmail === "bysonairy@gmail.com" ? 'admin' : 'user';
        const newUser = new User({ name, email: cleanEmail, password, role });
        await newUser.save();
        await new Notification({ email: cleanEmail, message: `Welcome to BYSONAIRY, ${name}! 💙 System Link Established.`, type: "info" }).save();
        res.json({ success: true, user: { name, email: cleanEmail, role } });
    } catch (e) { res.json({ success: false, message: "Email taken" }); }
});

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if(!email || !password) return res.json({ success: false, message: "Missing fields" });
        const cleanEmail = email.toLowerCase().trim();
        const user = await User.findOne({ email: cleanEmail, password });
        if (user) {
            await new Notification({ email: cleanEmail, message: `Login Detected: Welcome back, ${user.name}.`, type: "info" }).save();
            res.json({ success: true, user });
        } else { res.json({ success: false, message: "Invalid Credentials" }); }
    } catch(e) { res.json({ success: false }); }
});

// *** CRITICAL FIX: Listen on ALL interfaces (0.0.0.0) ***
app.listen(5000, '0.0.0.0', () => console.log("SYSTEM ACTIVE ON PORT 5000 (GLOBAL ACCESS)"));